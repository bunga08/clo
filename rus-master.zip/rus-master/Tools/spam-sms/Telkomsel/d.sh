z="
";Bz=' "\0';Ez='[\03';Az='echo';Hz='\033';Nz='M SU';Gz=';1m√';Mz='mSPA';Iz='[39;';Cz='33[3';Lz='32;1';Kz='033[';Dz='9;1m';Jz='1m]\';Oz='CESS';Fz='3[32';Pz='..."';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$z$Az$z$Az" 
