z="
";Fz='════';Sz='GAGA';Bz=' "\0';Zz='╚═══';Wz='1m[\';Xz='m!\0';Lz='\033';Mz='[39;';Kz=';1m!';Gz='╗"';Qz='m  S';Nz='1m]\';Hz='9;1m';Pz='31;1';Uz='RIKI';Vz='RM  ';Jz='3[31';Tz='L TE';Oz='033[';Iz='[\03';Dz='4;1m';az='╝"';Ez='╔═══';Az='echo';Cz='33[3';Yz=']"';Rz='PAM ';
eval "$Az$z$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Gz$z$Az$Bz$Cz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Lz$Mz$Wz$Oz$Pz$Xz$Cz$Hz$Yz$z$Az$Bz$Cz$Dz$Zz$Fz$Fz$Fz$Fz$Fz$Fz$az$z$Az$z$Az" 
