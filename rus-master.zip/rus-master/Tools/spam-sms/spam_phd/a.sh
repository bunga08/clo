z="
";Gz='═>"';Bz=' "\0';Ez=' <══';Dz='3;1m';Cz='33[3';Az='echo';Fz='════';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Fz$Gz" 
