# **54 TOOLS TERMUX**
# **Create: 2018**
# **update: 2019 versi 6.4**
# **----------------------**

# INSTALL DI TERMUX:
# $ pkg install bash
# $ pkg install python2
# $ pkg install git
# $ git clone https://github.com/Rusmana-ID/rus
# $ cd rus
# $ sh v2.sh

# **----------------------**
# **Jika sudah masuk silahkan pilih nomor 1 dulu untuk mendowdload username dan pasword nya jika**
# **sudah tau username dan pasword nya kalian pilih nomor 2 lalu silahkan login**

# **Setelah itu kalian pilih no 3 untuk subscribe channel youtube admin**
# **Jika sdh kalian pilih no 1 untuk install bahan2 nya jika gk di install bahan2 nya**
# **tools nya gk bakalan bisa di pakai atau akan terjadi error**

# **Lalu jika sdh kalian pilih nomor 2 untuk menjalankan tols nya**
# **dan Selamat menggunakan dan gunakan dengan bijak ya**
![5](https://user-images.githubusercontent.com/41493567/62385192-99104d80-b57e-11e9-8718-91f350b91159.png)
![4](https://user-images.githubusercontent.com/41493567/62385262-c6f59200-b57e-11e9-9b23-e44a583bbb12.png)
![3](https://user-images.githubusercontent.com/41493567/62385312-f4dad680-b57e-11e9-9475-85b051d613e2.png)
![2](https://user-images.githubusercontent.com/41493567/62385342-fefcd500-b57e-11e9-8da1-532f620a0107.png)
![1](https://user-images.githubusercontent.com/41493567/62385338-fe643e80-b57e-11e9-9c59-8ae11ab14689.png)




