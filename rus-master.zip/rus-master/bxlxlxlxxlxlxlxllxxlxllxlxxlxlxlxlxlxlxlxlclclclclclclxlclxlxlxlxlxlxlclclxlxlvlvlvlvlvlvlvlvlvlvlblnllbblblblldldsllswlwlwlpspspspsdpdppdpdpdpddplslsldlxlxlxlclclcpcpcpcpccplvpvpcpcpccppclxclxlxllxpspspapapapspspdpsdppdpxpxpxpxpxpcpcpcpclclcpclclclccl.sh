#!/data/data/com.termux/files/usr/bin/bash
p="\033[39;1m"
a="\033[30;1m"
m="\033[31;1m"
h="\033[32;1m"
k="\033[33;1m"
b="\033[34;1m"
c="\033[35;1m"

clear
printf "
${k}     ╔═══════════════════════════════════╗
${k}     ║ ${b}Dengan Adanya Tools Ini Tidak Akan${k}║
${k}     ║ ${b}  Menjadikan Mu Seorang Hacker,   ${k}║
${k}     ║ ${b} Cyber, Cracker, Anonymous Dan    ${k}║
${k}     ║ ${b}Antek2nya Tools Ini Di Buat Hanya ${k}║
${k}     ║ ${b}   Untuk Tujuan Baik Dan Tidak    ${k}║
${k}     ║ ${b}Melanggar Aturan Hukum Dan Agama  ${k}║
${k}     ╚═══════════════════════════════════╝\n
${b}      ✬   ${k}✬${m}   ✬${b}    ╔═══════╗${b}   ✬   ${k}✬${m}   ✬${b} 
${m}        ✬   ${c}✬    ${b}  ║       ║${m}     ✬   ${c}✬    ${b} 
${k}          ✬${b}      ╔═══════════╗${k}     ✬${b}
${p}     Black Coder ${b}║ ${p}L O G I N ${b}║  ${p}OFFICIAL 
${p}        Crush ${b}   ║ ${k}User&Pass ${b}║ 
${b}                 ╚═══════════╝\n
${p}         ╔═══════════╗      \n"
printf "         ║ ${b}Username${m}: ${h}√Succes\n"
printf "${p}         ╚═══════════╝ \n"
printf "                       ╔═══════════╗      \n"
printf "                       ║ ${b}Pasword${m}:  ${h}√Succes\n"
printf "${p}\a                       ╚═══════════╝ \n"
sleep 1
printf "${p}[${k}+${p}]${h} Login Success..\n"
sleep 1
sh install.sh